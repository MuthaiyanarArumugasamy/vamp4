import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import multer from 'multer';
import fs from 'fs';
import path from 'path';

const app = express();
const port = Number(process.env.PORT || 3000);
const db = new Database(process.env.DATABASE_FILE || './vamp4.db');
fs.mkdirSync('./uploads', { recursive: true });

app.use(helmet());
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));

const upload = multer({
  dest: './uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }
});

const schema = `
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 plan TEXT NOT NULL DEFAULT 'free',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS courses (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 description TEXT NOT NULL,
 level TEXT NOT NULL,
 price INTEGER NOT NULL DEFAULT 0,
 published INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 description TEXT NOT NULL,
 price INTEGER NOT NULL DEFAULT 0,
 file_path TEXT,
 published INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 item_type TEXT NOT NULL,
 item_id INTEGER NOT NULL,
 amount INTEGER NOT NULL,
 currency TEXT NOT NULL DEFAULT 'INR',
 provider TEXT NOT NULL DEFAULT 'paypal',
 provider_order_id TEXT,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS enrollments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 course_id INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(user_id, course_id)
);
`;
db.exec(schema);

function tokenFor(user) {
  return jwt.sign({ sub: user.id, role: user.role, plan: user.plan }, process.env.JWT_SECRET, { expiresIn: '7d' });
}
function auth(req,res,next){
  const h=req.headers.authorization||'';
  const token=h.startsWith('Bearer ')?h.slice(7):null;
  if(!token) return res.status(401).json({error:'Authentication required'});
  try { req.user=jwt.verify(token,process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({error:'Invalid or expired token'}); }
}
function admin(req,res,next){ if(req.user?.role!=='admin') return res.status(403).json({error:'Admin access required'}); next(); }

app.get('/api/health',(req,res)=>res.json({ok:true,service:'vamp4-backend'}));

app.post('/api/auth/register', async (req,res)=>{
  const {name,email,password}=req.body||{};
  if(!name||!email||!password||password.length<8) return res.status(400).json({error:'Name, email and an 8+ character password are required'});
  const normalized=String(email).trim().toLowerCase();
  try {
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(String(name).trim(),normalized,hash);
    const user={id:Number(info.lastInsertRowid),name:String(name).trim(),email:normalized,role:'user',plan:'free'};
    res.status(201).json({user,token:tokenFor(user)});
  } catch(e){ res.status(409).json({error:'Email is already registered'}); }
});

app.post('/api/auth/login', async (req,res)=>{
  const {email,password}=req.body||{};
  const user=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').trim().toLowerCase());
  if(!user || !(await bcrypt.compare(password||'',user.password_hash))) return res.status(401).json({error:'Invalid email or password'});
  const safe={id:user.id,name:user.name,email:user.email,role:user.role,plan:user.plan};
  res.json({user:safe,token:tokenFor(safe)});
});

app.get('/api/courses',(req,res)=>res.json(db.prepare('SELECT * FROM courses WHERE published=1 ORDER BY id DESC').all()));
app.post('/api/courses',auth,admin,(req,res)=>{
  const {title,description,level='Beginner',price=0}=req.body||{};
  if(!title||!description) return res.status(400).json({error:'title and description required'});
  const info=db.prepare('INSERT INTO courses(title,description,level,price) VALUES(?,?,?,?)').run(title,description,level,Number(price));
  res.status(201).json({id:Number(info.lastInsertRowid)});
});

app.get('/api/products',(req,res)=>res.json(db.prepare('SELECT id,title,description,price,published FROM products WHERE published=1 ORDER BY id DESC').all()));
app.post('/api/products',auth,admin,(req,res)=>{
  const {title,description,price=0}=req.body||{};
  if(!title||!description) return res.status(400).json({error:'title and description required'});
  const info=db.prepare('INSERT INTO products(title,description,price) VALUES(?,?,?)').run(title,description,Number(price));
  res.status(201).json({id:Number(info.lastInsertRowid)});
});

app.get('/api/me',auth,(req,res)=>res.json(db.prepare('SELECT id,name,email,role,plan,created_at FROM users WHERE id=?').get(req.user.sub)));
app.get('/api/me/courses',auth,(req,res)=>res.json(db.prepare(`SELECT c.* FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE e.user_id=?`).all(req.user.sub)));

app.post('/api/enrollments',auth,(req,res)=>{
  const courseId=Number(req.body?.courseId);
  const course=db.prepare('SELECT * FROM courses WHERE id=? AND published=1').get(courseId);
  if(!course) return res.status(404).json({error:'Course not found'});
  if(course.price>0) return res.status(402).json({error:'Payment required',courseId:course.id,amount:course.price,currency:'INR'});
  db.prepare('INSERT OR IGNORE INTO enrollments(user_id,course_id) VALUES(?,?)').run(req.user.sub,courseId);
  res.json({ok:true});
});

app.post('/api/uploads',auth,admin,upload.single('file'),(req,res)=>{
  if(!req.file) return res.status(400).json({error:'No file uploaded'});
  res.json({ok:true,file:req.file.filename,originalName:req.file.originalname});
});

// Transport and map endpoints intentionally return a clear provider-required state until real licensed APIs are configured.
for (const type of ['bus','train','flight']) {
  app.post(`/api/transport/${type}`,auth,(req,res)=>res.json({live:false,type,message:`Connect an approved ${type} data provider on the server to return live data.`,query:req.body||{}}));
}
app.post('/api/map/search',auth,(req,res)=>res.json({live:false,message:'Connect a licensed map/geocoding provider on the server.',query:req.body||{}}));

app.post('/api/ai/chat',auth,async(req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'AI provider is not configured on the backend'});
  // Add your chosen AI SDK/provider here. Never expose the provider secret to the browser.
  res.status(501).json({error:'AI provider adapter not implemented yet'});
});

app.post('/api/payments/create-order',auth,(req,res)=>{
  // PayPal order creation belongs here. Keep PayPal credentials in .env and verify the order server-side before granting access.
  if(!process.env.PAYPAL_CLIENT_ID || !process.env.PAYPAL_CLIENT_SECRET) return res.status(503).json({error:'PayPal is not configured'});
  res.status(501).json({error:'PayPal adapter not implemented yet'});
});
app.post('/api/payments/capture-order',auth,(req,res)=>res.status(501).json({error:'Implement server-side PayPal capture and verification before activating a purchase'}));

app.get('/api/admin/stats',auth,admin,(req,res)=>{
  const count=(table)=>db.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n;
  res.json({users:count('users'),courses:count('courses'),products:count('products'),orders:count('orders')});
});

app.use((err,req,res,next)=>{ console.error(err); res.status(500).json({error:'Internal server error'}); });
app.listen(port,()=>console.log(`Vamp4 backend running on http://localhost:${port}`));
