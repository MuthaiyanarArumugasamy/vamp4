# Vamp4 Backend

Node.js + Express + SQLite starter backend for the Vamp4 single-file frontend.

## 1. Install

```bash
npm install
cp .env.example .env
```

Set a long random `JWT_SECRET` in `.env`.

## 2. Run

```bash
npm start
```

Health check: `GET /api/health`

## 3. Frontend connection

The supplied `index.html` already uses `/api/...` endpoint placeholders. Serve the HTML from the same domain (recommended) or configure CORS for your frontend origin.

## 4. Payments

PayPal credentials belong only in `.env`. Do not put secrets in `index.html`, GitHub, client-side JavaScript, or public files. Implement server-side PayPal order creation, capture, webhook verification and database updates before granting course/product access.

## 5. Production requirements

Use HTTPS, a strong JWT/session strategy, database backups, email verification/password reset, CSRF protection where applicable, upload MIME/type validation, malware scanning for public uploads, object storage for large files, rate limiting, audit logs, secure admin RBAC, privacy/retention controls, and provider-specific compliance.

Transport, map and AI routes are deliberately provider-neutral. Connect only APIs you are licensed/authorised to use.
